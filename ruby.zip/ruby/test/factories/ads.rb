FactoryBot.define do
  factory :ad do
    title { "MyString" }
    description { "MyText" }
    prince { 1 }
    user { nil }
  end
end
